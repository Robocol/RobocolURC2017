from django.apps import AppConfig


class MostrarlistaConfig(AppConfig):
    name = 'MostrarLista'
